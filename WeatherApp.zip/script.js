document.addEventListener('DOMContentLoaded', function() {
    const apiKey = "403b71195ada4156d0752decbaa6d7b1";
    const cityInput = document.getElementById('cityInput');
    const getWeatherBtn = document.getElementById('getWeatherBtn');
    const weatherInfo = document.getElementById('weatherInfo');

    getWeatherBtn.addEventListener('click', function() {
        const city = cityInput.value.trim();
        if (city !== '') {
            getWeather(city);
        }
    });

    async function getWeather(city) {
        const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;
        try {
            const response = await fetch(url);
            const data = await response.json();
            displayWeather(data);
        } catch (error) {
            console.error('Error fetching weather data:', error);
        }
    }

    function displayWeather(data) {
        if (data.cod === 200) {
            const city = data.name;
            const temp = data.main.temp;
            const feelsLike = data.main.feels_like;
            const description = data.weather[0].description;
            const windSpeed = data.wind.speed;
            const tempCelsius = temp.toFixed(2);

            const output = `
                <p>City: ${city}</p>
                <p>Temperature: ${tempCelsius}�C</p>
                <p>Feels Like: ${feelsLike}�C</p>
                <p>Description: ${description}</p>
                <p>Wind Speed: ${windSpeed} m/s</p>
            `;
            weatherInfo.innerHTML = output;
            weatherInfo.style.display = 'block';
        } else {
            weatherInfo.innerHTML = 'Error: Could not retrieve weather data.';
            weatherInfo.style.display = 'block';
        }
    }
});
